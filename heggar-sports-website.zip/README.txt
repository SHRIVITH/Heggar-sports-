HEGGAR SPORTS WEBSITE

Files:
- index.html
- style.css
- script.js

HOW TO USE
1. Open script.js.
2. Replace 919999999999 with your real WhatsApp number including 91.
3. Open index.html and replace yourmail@example.com with your email.
4. Add your real Heggar Sports jersey/team photos in the Gallery section.
5. Upload all three website files to Netlify.

The website is responsive for desktop and mobile.
